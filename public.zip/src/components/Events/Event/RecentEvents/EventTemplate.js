// Import React and CSS module
import React from 'react';
import styles from './EventTemplate.module.css'; // Make sure to replace with your actual CSS module path
import theme from "../../../../assets/images/theme.jpg"
import Faq from './Faq';
// import Card from 'react-bootstrap/Card';
import 'bootstrap/dist/css/bootstrap.min.css';  
import {Container ,Card,Row, Col, Button} from 'react-bootstrap';  
// import img1 from './img1.jpg';
// Functional component for the template
const EventTemplate = () => {
    const cardData = [
        {
            title: 'Card Title 1',
            subtitle: 'Card Subtitle 1',
            icon: 'bx bx-file',
            text: 'Incubation Opportunity ',
            
        },
        {
            title: 'Card Title 2',
            subtitle: 'Card Subtitle 2',
            icon: 'bx bx-file',
            text: 'Mentoring session',
           
        },
        {
            title: 'Card Title 3',
            subtitle: 'Card Subtitle 3',
            icon: 'bx bx-file',
            text: 'Certificates',
            
        },
        {
            title: 'Card Title 4',
            subtitle: 'Card Subtitle 3',
            icon: 'bx bx-file',
            text: 'Goodies and Swags',
            
        },
    ];
    return (
        <main className={styles.main}>
            <section className={`${styles.section} ${styles.banner} ${styles['banner-section']}`}>
                <div className={`${styles.container} ${styles['banner-column']}`}>
                    {/* Image Section */}
                    <img
                        className={styles['banner-image']}
                        src="https://i.imgur.com/Nhmt2wY.png"  // Replace 'your-image.jpg' with your actual image file
                        alt="Event Illustration"
                        id={styles.img1}
                    />

                    {/* Text Section */}
                    <div className={styles['banner-inner']}>
                        <h1 className={styles['heading-xl']}>What is Google - Ideate?</h1>
                        <p className={styles.paragraph}>
                            Get ready to unleash your creativity and innovation at Ideathon, an exciting event designed for college students to showcase their brilliant ideas and compete for enticing prizes. Whether you're passionate about technology, social impact, or creative arts, Ideathon is the stage for you. This ideation extravaganza invites students from diverse backgrounds to present their groundbreaking concepts, providing a platform for networking, collaboration, and mentorship opportunities. Our expert judging panel will evaluate your ideas, offering valuable feedback to refine your vision. Ideathon is not just an event; it's a celebration of ingenuity and a chance to turn your ideas into reality. Join us for a day filled with inspiration, connection, and the thrill of winning exciting prizes.
                        </p>
                    </div>
                </div>
            </section>
            <section className={`${styles.section} ${styles['section-2']}`}>
                <div className={`${styles.container} ${styles['section-column']}`}>

                    <h2 className={styles['heading-lg-2']}>Themes</h2>
                    <p className={styles.paragraph}>
                        Innovation for a sustainable future by solving real-world problems. This Ideathon is a sector-agnostic activity, where participants can come up with innovative solutions from any field including, but not limited to, the following themes.


                    </p>

                </div>
                <div className={`${styles.container} ${styles['section-column']}`}>
                    <img className={styles['section-image']} src={theme} alt="Illustration" id={styles.img1}/>
                </div>

            </section>
            <section className={`${styles.section} ${styles['section-2']}`}>

                <Faq />

            </section>

            {/* <section className={`${styles.section} ${styles['section-2']}`}>
                <div className={`${styles.container} ${styles['section-column']}`}>

                    <h2 className={styles['heading-lg-2']}>What's in it for you?</h2>
                    <p className={styles.paragraph}>
                        Cash prizes worth Rs. 10,000 to be won.
                    </p>
                    <div className={styles.card}>
                        {cardData.map((card, index) => (
                            <Card key={index} style={{ width: '18rem' }}>
                                <Card.Body>
                                    
                                    <Card.Title>{card.title}</Card.Title>
                                    <Card.Subtitle className="mb-2 text-muted">{card.subtitle}</Card.Subtitle>
                                    <Card.Text>{card.text}</Card.Text>
                                    
                                </Card.Body>
                            </Card>
                        ))}
                    </div>

                </div>

            </section> */}
            
           
        </main>
    );
};

export default EventTemplate;
