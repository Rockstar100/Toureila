import React from 'react'
import './Faq.css'

export default function Faq() {
  return (
    <div> <section id="faq" className="faq section-bg">
    <div className="container" data-aos="fade-up">
      <div className="section-title">
        <h2  className='heading-lg-2'>Frequently Asked Questions</h2>
        <p>Questions you might have and their answers</p>
      </div>

      <div class="faq-list">
        <ul>
          <li data-aos="fade-up">
            <i class="bx bx-help-circle icon-help"></i>
            <a data-bs-toggle="collapse" class="collapse" data-bs-target="#faq-list-1">What is Google Ideate- Ideathon? <i
                class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
            <div id="faq-list-1" class="collapse show" data-bs-parent=".faq-list">
              <p>
              Google Ideate (G-Ideate) is an exciting Ideathon organized by GDSC SVIET, providing a platform for college students to unleash their creativity and innovation. It's a celebration of ingenuity, inviting participants from diverse backgrounds to showcase their brilliant ideas and compete for enticing prizes. G-Ideate is not just an event; it's an opportunity to turn your imaginative concepts into reality.
              </p>
            </div>
          </li>

          <li data-aos="fade-up" data-aos-delay="100">
            <i class="bx bx-help-circle icon-help"></i>
            <a data-bs-toggle="collapse" data-bs-target="#faq-list-2" class="collapsed">Who can participate in G-Ideate?
              <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
            <div id="faq-list-2" class="collapse" data-bs-parent=".faq-list">
              <p>
              G-Ideate is open to college students who are passionate about technology, social impact, and creative arts. Participants can come from various academic backgrounds and fields of study. Whether you're a computer science enthusiast, a social entrepreneur, or an artist with a unique perspective, G-Ideate welcomes individuals with a passion for innovation.
              </p>
            </div>
          </li>
          <li data-aos="fade-up" data-aos-delay="100">
            <i class="bx bx-help-circle icon-help"></i>
            <a data-bs-toggle="collapse" data-bs-target="#faq-list-3" class="collapsed">What are the themes for G-Ideate Ideathon 2024?
              <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
            <div id="faq-list-3" class="collapse" data-bs-parent=".faq-list">
              <p>
              The Ideathon focuses on the theme of "Innovation for a Sustainable Future." Participants are encouraged to solve real-world problems through innovative solutions. The Ideathon is sector-agnostic, allowing participants to explore and present ideas from various fields. Some suggested themes include, but are not limited to, the 17 United Nations Sustainable Development Goals (SDGs).
              </p>
            </div>
          </li>
          <li data-aos="fade-up" data-aos-delay="100">
            <i class="bx bx-help-circle icon-help"></i>
            <a data-bs-toggle="collapse" data-bs-target="#faq-list-4" class="collapsed">What can I expect at G-Ideate Ideathon?
              <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
            <div id="faq-list-4" class="collapse" data-bs-parent=".faq-list">
              <p>
              G-Ideate offers a unique opportunity to network, collaborate, and receive mentorship from industry experts. During the event, participants will showcase their groundbreaking concepts, and an expert judging panel will evaluate ideas, providing valuable feedback to refine visions. Expect a day filled with inspiration, connection, and the thrill of winning exciting prizes.
              </p>
            </div>
          </li>
          <li data-aos="fade-up" data-aos-delay="100">
            <i class="bx bx-help-circle icon-help"></i>
            <a data-bs-toggle="collapse" data-bs-target="#faq-list-5" class="collapsed">How Can I Register for G-Ideate Ideathon 2024?
              <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
            <div id="faq-list-5" class="collapse" data-bs-parent=".faq-list">
              <p>
              Navigate to the official G-Ideate Ideathon 2024 website. You can easily access the website by clicking on the "Apply Now" button located above.You will be redirected to the registration form. Fill out the required information accurately. After Reveiwing we will maill that your registration is accepted or not
              </p>
            </div>
          </li>
          
        </ul>
      </div>
    </div>
  </section></div>
  )
}
