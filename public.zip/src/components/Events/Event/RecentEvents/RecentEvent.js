import React from 'react'

function RecentEvent() {
  return (
    <div>RecentEvent</div>
  )
}

export default RecentEvent