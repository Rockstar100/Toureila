import React from 'react'
import classes from './Idea.module.css';
import EventTemplate from './EventTemplate';
import Faq from './Faq';
import Whats from './Whats';
import Footer from '../../../UI/Footer/Footer';
import splash from '../../../../assets/images/splash.png';


function Ideathon(props) {
    let styles = classes;
  if (props.theme) {
    styles = classes;
  } 
  return (
    <div>
        <main className={styles.main}>
    <section className={`${styles.section} ${styles.banner} ${styles['banner-section']}`}>
      <div className={`${styles.container} ${styles['banner-column']}`}>
        <img className={styles['banner-image']} id={styles.img1} src={splash} alt="Illustration" />
        <div className={styles['banner-inner']}>
          <h1 className={styles['heading-xl']}>Spark Innovation: <br/> Register Now for Google Ideate Ideathon 2024.</h1>
          <p className={styles.paragraph}>
          Unleash your creativity with Google Ideate! Register now for our Ideathon and turn your amazing ideas into reality. Showcase your skills, collaborate with fellow thinkers, and win cool prizes. Limited seats available, so hurry and register today. Don't miss out on this chance to bring your imagination to life!</p>
          <button className={`${styles.btn} ${styles['btn-darken']} ${styles['btn-inline']}`}>
            Register Now<i className="bx bx-right-arrow-alt"></i>
          </button>
        </div>
      </div>
    </section>
  </main>
  <EventTemplate/>
  <Whats/>
  <Footer/>
 
    </div>
  )
}

export default Ideathon