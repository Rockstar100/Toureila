// import images
import idea from "../../assets/images/1704869510049.jpg";

export const EventsData = [
  {
    id: 6,
    cardTitle: "Google Ideate Ideathon",
    cardSubtitle: "Feb 10, 2024, 10:00 AM – 5:00 PM",
    cardText:"Unleash your creativity with Google Ideate! Register now for our Ideathon and turn your amazing ideas into reality. Showcase your skills, collaborate with fellow thinkers, and win cool prizes. Limited seats available, so hurry and register today. Don't miss out on this chance to bring your imagination to life!",
    cardHref:
      "/ideathon",
    eventImg: idea,
  },
  {
    id: 5,
    cardTitle: "Android Workshop",
    cardSubtitle: "Dec 12, 2023, 7:00 – 8:00 PM",
    cardText:"We are thrilled to share the exciting news about the upcoming Android Campaign Workshop, set to kick off on the 12th of December. This workshop is designed to be both informative and hands-on, offering participants a unique opportunity to delve into the world of Android development.",
    cardHref:
      "https://gdsc.community.dev/events/details/developer-student-clubs-swami-vivekanand-institute-of-engineering-technology-chandigarh-presents-android-workshop/",
    eventImg: "https://res.cloudinary.com/startup-grind/image/upload/c_fill,w_500,h_500,g_center/c_fill,dpr_2.0,f_auto,g_center,q_auto:good/v1/gcs/platform-data-dsc/events/Android%20Workshop_5Jzt8uL.png",
  },
  {
    id: 4,
    cardTitle: "Solution Challenge",
    cardSubtitle: "3 Jul 2021 - 6 Jul 2021",
    cardText:
      "The Google Developer Student Clubs 2024 Solution Challenge mission is to solve for one of the United Nations’ 17 Sustainable Development Goals using Google technology.Join this event to hear more about GDSC solution challenge rules, timeline, judging criteria, and other details.",
    cardHref:
      "https://gdsc.community.dev/events/details/developer-student-clubs-swami-vivekanand-institute-of-engineering-technology-chandigarh-presents-getting-started-with-solution-challenge/",
    eventImg: "https://res.cloudinary.com/startup-grind/image/upload/c_fill,w_500,h_500,g_center/c_fill,dpr_2.0,f_auto,g_center,q_auto:good/v1/gcs/platform-data-dsc/events/google-solution-challenge-2021.jpg",
  },
  {
    id: 3,
    cardTitle: "Bharat TechXperience Hackathons",
    cardSubtitle: "Oct 28, 2023, 10:32 AM – Oct 29, 2023, 10:32 AM",
    cardText:
      "Join us for the Bharat TechXperience, a two-day hackathon happening on October 28-29. 📅Are you ready to dive into the world of tech innovation and creativity?",
    cardHref:
      "https://gdsc.community.dev/events/details/developer-student-clubs-swami-vivekanand-institute-of-engineering-technology-chandigarh-presents-bharat-techxperience-hackathon/",
    eventImg: "https://res.cloudinary.com/startup-grind/image/upload/c_fill,w_500,h_500,g_center/c_fill,dpr_2.0,f_auto,g_center,q_auto:good/v1/gcs/platform-data-dsc/events/WhatsApp%20Image%202023-09-30%20at%2011.05.24.jpg",
  },
  {
    id: 2,
    cardTitle: "Google Cloud Study Jam",
    cardSubtitle: "Sep 1, 2023, 12:00 AM – Oct 1, 2023, 12:15 AM",
    cardText:
      "We're excited to announce our upcoming program, the Cloud Study Jam, designed exclusively for those of you interested in diving into the world of cloud computing.",
    cardHref: "https://gdsc.community.dev/events/details/developer-student-clubs-swami-vivekanand-institute-of-engineering-technology-chandigarh-presents-google-cloud-study-jam-2023-09-01/",
    eventImg: "https://res.cloudinary.com/startup-grind/image/upload/c_fill,w_500,h_500,g_center/c_fill,dpr_2.0,f_auto,g_center,q_auto:good/v1/gcs/platform-data-dsc/events/WhatsApp%20Image%202023-09-21%20at%209.59.27%20PM.jpeg",
  },
  {
    id: 1,
    cardTitle: "Inaugural Event",
    cardSubtitle: "Aug 11, 2023, 11:00 AM – 2:00 PM",
    cardText:
      "Absolutely, here's a more detailed description of the inaugural event for the Google Developer Student Club (GDSC) at Swami Vivekananda Institute of Engineering and Technology:Step into a realm of boundless innovation and technological empowerment as we proudly announce the launch of the GDSC Sviet. ",
    cardHref: "https://gdsc.community.dev/events/details/developer-student-clubs-swami-vivekanand-institute-of-engineering-technology-chandigarh-presents-inaugural-event/",
    eventImg: "https://dicoding-web-img.sgp1.cdn.digitaloceanspaces.com/original/event/dos:gdsc_universitas_mikroskil_info_session_2023_logo_121023120101.png",
  },
];
