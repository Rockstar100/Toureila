import React from 'react'
import './Faq.css'

export default function Faq() {
  return (
    <div> <section id="faq" class="faq section-bg">
    <div class="container" data-aos="fade-up">
      <div class="section-title">
        <h2>Frequently Asked Questions</h2>
        <p>Questions you might have and their answers</p>
      </div>

      <div class="faq-list">
        <ul>
          <li data-aos="fade-up">
            <i class="bx bx-help-circle icon-help"></i>
            <a data-bs-toggle="collapse" class="collapse" data-bs-target="#faq-list-1">What is GDSC? <i
                class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
            <div id="faq-list-1" class="collapse show" data-bs-parent=".faq-list">
              <p>
                Google Developer Student Clubs are university based
                community groups for students interested in Google developer
                technologies.Students from all undergradu ate or
                postgraduate programs with an interest in growing as a
                developer can join GDSC.
              </p>
            </div>
          </li>

          <li data-aos="fade-up" data-aos-delay="100">
            <i class="bx bx-help-circle icon-help"></i>
            <a data-bs-toggle="collapse" data-bs-target="#faq-list-2" class="collapsed">What are the benefits of
              joining GDSC?
              <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
            <div id="faq-list-2" class="collapse" data-bs-parent=".faq-list">
              <p>
                Professional growth:It includes having access to technical
                expertise and community management training. Network growth:
                Access to a global network of student leaders,professional
                community organizers,industry experts .
              </p>
            </div>
          </li>

          <li data-aos="fade-up" data-aos-delay="200">
            <i class="bx bx-help-circle icon-help"></i>
            <a data-bs-toggle="collapse" data-bs-target="#faq-list-3" class="collapsed">Is GDSC only for students in
              computer science?

              <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
            <div id="faq-list-3" class="collapse" data-bs-parent=".faq-list">
              <p>
                No! Students from all programs who are interested in growing
                as a developer can join GDSC.
              </p>
            </div>
          </li>

          
        </ul>
      </div>
    </div>
  </section></div>
  )
}
