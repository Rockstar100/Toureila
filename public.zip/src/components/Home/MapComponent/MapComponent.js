import React from "react";

//import css
import classes from "./MapComponent.module.css";

const MapComponent = (props) => {
  let styles = "invert(0%)";
  if (props.theme) {
    styles = "invert(0%)";
  } else {
    styles = "invert(90%)";
  }
  return (
    <div className={classes.mapContainer}>
      <div className={classes.mapdiv}>
        <div className={classes.iframediv}>
          <iframe
            title={"map"}
            src=""
            width="100%"
            frameBorder={0}
            style={{ border: 0, filter: styles }}
            allowFullScreen
            aria-hidden="false"
            tabIndex={0}
          ></iframe>
        </div>
      </div>
    </div>
  );
};

export default MapComponent;
