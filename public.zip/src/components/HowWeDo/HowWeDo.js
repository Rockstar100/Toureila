import React from 'react';
import a1 from '../../assets/images/howwedoit.png';

const HowWeDo = () => {
  return (
    <div className='mt-5 mb-5'>
      <div className='row justify-content-center'>
        <div className='col-md-10'>
          <div className='bg-white p-4 rounded'>
            <h1 className='text-primary fw-bold'>How We Do it here :)</h1>
            <h2 className='text-secondary'>it's a cycle</h2>
          </div>
          <img src={a1} alt='How we do' className='img-fluid' />
        </div>
      </div>
    </div>
  );
};

export default HowWeDo;
