# What is this for?
For you guys to learn and understand the code structure and implement the things on this repo.
Thanks. 🙂😁

# DSC-AKGEC-Website
Rules - 
1. Everyone will have to push their code to their own branches before pushing it onto the main branches. 
2. Make changes to this repo by forking it to you personal github ids. 
3. Keep the code well documented and make proper commit messages to let everyone know who has implemented which feature. 
4. Use <h2>NPM</h2> as package manager